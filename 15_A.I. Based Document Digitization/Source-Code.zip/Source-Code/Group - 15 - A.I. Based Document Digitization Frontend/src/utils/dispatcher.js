import { CLEAR_ERRORS } from "../actions/types";
export const clearErrors = () => {
  return {
    type: CLEAR_ERRORS,
  };
};
